#include "videos.h"
videos::videos()
{
    id=0;
    nombre="a";
    duracion=0;
    genero="a";//ctor
}
videos::videos(int _id,string _nombre,int _duracion,string _genero)
{
    id=_id;
    nombre=_nombre;
    duracion=_duracion;
    genero=_genero;
}
int videos::get_id(){
    return id;
}
string videos::get_nombre(){
    return nombre;
}
int videos::get_duracion(){
    return duracion;
}
string videos::get_genero(){
    return genero;
}
void videos::set_id(int _id){
    id=_id;
}
void videos::set_nombre(string _nombre){
    nombre=_nombre;
}
void videos::set_duracion(int _duracion){
    duracion=_duracion;
}
void videos::set_genero(string _genero){
    genero=_genero;
}

