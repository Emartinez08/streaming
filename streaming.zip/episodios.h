#define EPISODIOS_H
#include <iostream>
#include <stdlib.h>
#include<string>
using namespace std;

class episodios
{
    public:
        episodios();
        episodios(string,int);
        string get_titulo();
        int get_temporada();
        void set_titulo(string);
        void set_temporada(int);
    protected:

    private:
        string titulo;
        int temporada;
};