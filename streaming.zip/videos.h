#ifndef VIDEOS_H
#define VIDEOS_H
#include <iostream>
#include <stdlib.h>
#include<string>
using namespace std;

class videos
{
    public:
        videos();
        videos(int,string,int,string);
        int get_id();
        string get_nombre();
        int get_duracion();
        string get_genero();
        void set_id(int);
        void set_nombre(string);
        void set_duracion(int);
        void set_genero(string);
    protected:

    private:
        int id;
        string nombre;
        int duracion;
        string genero;
};

