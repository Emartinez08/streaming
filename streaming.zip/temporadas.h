#define TEMPORADAS_H
#include "episodios.h"
#include <iostream>
#include <stdlib.h>
#include<string>
using namespace std;

class temporadas : public episodios
{
    public:
        temporadas();
        temporadas(string,episodios,episodios,int);
        string get_nombre();
        episodios get_episodios();
        episodios get_episodios();
        int get_calificacion();
        void set_nombre(string);
        void set_epispodios(episodios);
        void set_epispodios(episodios);
        void set_calificacion(int);
    protected:

    private:
        string nombre;
        class episodios episodios;
        class episodios episodios;
        int calificacion;
};