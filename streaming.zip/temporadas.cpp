#include "temporadas.h"
temporadas::temporadas()
{
    nombre="a";
    episodios=episodios;
    episodios=episodios;
    calificacion=0;//ctor
}
temporadas::temporadas(string _nombre,class episodios _episodios,class episodios _episodios2,int _calificacion)
{
    nombre=_nombre;
    episodios=_episodios;
    episodios=_episodios;
    calificacion=_calificacion;
}
string temporadas::get_nombre(){
    return nombre;
}
class episodios temporadas::get_episodios(){
    return episodios;
}
class episodios temporadas::get_episodios(){
    return episodios;
}
int temporadas::get_calificacion(){
    return calificacion;
}
void temporadas::set_nombre(string _nombre){
    nombre=_nombre;
}
void temporadas::set_epispodios(class episodios _episodios){
    episodios=_episodios;
}
void temporadas::set_epispodios(class episodios _episodios){
    episodios=_episodios;
}
void temporadas::set_calificacion(int _calificacion){
    calificacion=_calificacion;
}

