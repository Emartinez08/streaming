#ifndef PELICULAS_H
#define PELICULAS_H
#include "videos.h"
using namespace std;


class peliculas : public videos
{
    public:
        peliculas();
        peliculas(videos);

    protected:

    public:
        class videos videos;
        int calificacion;
};

