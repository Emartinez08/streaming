#define SERIES_H
#include "temporadas.h"
#include <iostream>
#include <stdlib.h>
#include<string>
using namespace std;

class series : public videos 
{
    public:
        series();
        temporadas(int,string,int,string,temporadas,temporadas);
        episodios get_temporadas();
        episodios get_temporadas();
        float get_calificacion();
        void set_temporadas(temporadas);
        void set_temporadas(temporadas);
        void set_calificacion(float)
    protected:

    private:
        class temporadas temporadas;
        class temporadas temporadas;
        float calificacion;
};