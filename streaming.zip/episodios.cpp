#include "episodios.h"
episodios::episodios()
{
    titulo="a";
    temporada=0;//ctor
}
episodios::episodios(string _titulo,int _temporada)
{
    titulo=_titulo;
    temporada=_temporada;
}
string episodios::get_titulo(){
    return titulo;
}
int episodios::get_temporada(){
    return temporada;
}
void episodios::set_titulo(string _titulo){
    titulo=_titulo;
}
void episodios::set_temporada(int _temporada){
    temporada=_temporada;
}