#include "series.h"
series::series()
{
    nombre="a";
    temporadas=temporadas;
    temporadas=temporadas;
    calificacion=0;//ctor
}
series::series(string _nombre,class temporadas _temporadas,class temporadas _temporadas,int _calificacion)
{
    nombre=_nombre;
    episodios=_episodios;
    episodios=_episodios;
    calificacion=_calificacion;
}
string temporadas::get_nombre(){
    return nombre;
}
class episodios temporadas::get_episodios(){
    return episodios;
}
class episodios temporadas::get_episodios(){
    return episodios;
}
int temporadas::get_calificacion(){
    return calificacion;
}
void temporadas::set_nombre(string _nombre){
    nombre=_nombre;
}
void temporadas::set_epispodios(class episodios _episodios){
    episodios=_episodios;
}
void temporadas::set_epispodios(class episodios _episodios){
    episodios=_episodios;
}
void temporadas::set_calificacion(int _calificacion){
    calificacion=_calificacion;
}

